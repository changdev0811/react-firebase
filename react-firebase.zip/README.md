# React-Redux Firebase App

## Installation
Run `npm install` to install all the required dependencies

Then run `npm start` to start a dev server.

Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Config
```javascript
const config = {
  apiKey: "AIzaSyDqrySIMY5aWSzLTNbuHkluPeIMIWmRLDU",
  authDomain: "react-firebase-9ec4a.firebaseapp.com",
  databaseURL: "https://react-firebase-9ec4a.firebaseio.com",
  projectId: "react-firebase-9ec4a",
  storageBucket: "react-firebase-9ec4a.appspot.com",
  messagingSenderId: "1028587710969"
};
```

This is my firebase config.
You could replace it to your firebase key.
In firebase database, you need to create users, scores, services collection.





